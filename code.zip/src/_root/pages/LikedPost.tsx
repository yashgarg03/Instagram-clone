import React from 'react'

const LikedPost = () => {
  return (
    <div>LikedPost</div>
  )
}

export default LikedPost