import React from 'react'

const UpdatePost = () => {
  return (
    <div>UpdatePost</div>
  )
}

export default UpdatePost